export interface EstimateGraph{
    name: string,
    earlyStart: number,
    earlyFinish: number,
    lateStart: number,
    lateFinish: number
}
