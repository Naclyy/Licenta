export interface Skills{
    id: number,
    skills: string
}