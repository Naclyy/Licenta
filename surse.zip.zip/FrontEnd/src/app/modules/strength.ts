export interface Strength{
    id: number,
    keyStrengths: string
}