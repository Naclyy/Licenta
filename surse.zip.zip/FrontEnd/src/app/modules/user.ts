export interface User{
    userId: number
    firstName: string
    lastName: string
    position: string | null
    email: string
    password: string
}
