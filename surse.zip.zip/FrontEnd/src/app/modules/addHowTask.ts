export interface addHowTask{
    objective: string,
    estimated_days: number,
}
