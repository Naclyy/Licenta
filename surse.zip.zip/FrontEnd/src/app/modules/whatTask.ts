export interface whatTask{
    taskId: number,
    objective: string | null,
    dateAdded: string | null,
    deadline: string | null
}
