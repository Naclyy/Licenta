export interface howTask{
    taskId: number,
    userId: number,
    whatId: number,
    objectives: string,
    estimatedTime: number,
}
