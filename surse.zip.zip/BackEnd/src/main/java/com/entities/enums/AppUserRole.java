package com.entities.enums;

public enum AppUserRole {
    USER,
    ADMIN
}
